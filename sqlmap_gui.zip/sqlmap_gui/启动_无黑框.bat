@echo off
chcp 65001 >nul
title sqlmap GUI
cd /d "%~dp0"

rem 优先使用 pythonw.exe（无控制台窗口）
where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw sqlmap_gui.py
    exit /b
)

rem 备用：用 VBS 隐藏窗口启动 python
echo Set WshShell = CreateObject("WScript.Shell") > "%temp%\run_hidden.vbs"
echo WshShell.Run "python ""%~dp0sqlmap_gui.py""", 0, False >> "%temp%\run_hidden.vbs"
cscript //nologo "%temp%\run_hidden.vbs"
del "%temp%\run_hidden.vbs"
