#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sqlmap GUI - 图形化界面版
基于 sqlmap 的可视化渗透测试工具
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import os
import sys
import json
import ctypes

# ============================================================
# 全局配置
# ============================================================
SQLMAP_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sqlmap", "sqlmap.py")
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gui_config.json")
# sqlmap 默认输出目录
DEFAULT_OUTPUT_DIR = os.path.join(os.environ.get("LOCALAPPDATA", ""), "sqlmap", "output")

# Tamper 脚本描述字典（基于 sqlmap 官方文档）
TAMPER_DESC = {
    "0eunion": "数字后 UNION → e0UNION，绕过整型比较（MySQL/MSSQL）",
    "apostrophemask": "单引号 → UTF-8 全角 ＇ (%EF%BC%87)，绕过单引号过滤",
    "apostrophenullencode": "单引号 → %00%27（空字节前缀编码）",
    "appendnullbyte": "末尾追加空字节 %00（Access）",
    "base64encode": "Base64 编码整个 payload",
    "between": "= → BETWEEN，> → NOT BETWEEN",
    "binary": "SELECT 后注入 BINARY 关键字（MySQL）",
    "bluecoat": "空格随机化，= → LIKE，可用于 SGOS 等环境",
    "chardoubleencode": "对整个 payload 进行两次 URL 编码",
    "charencode": "URL 编码所有字符",
    "charunicodeencode": "Unicode URL 编码（如 ' → %u0027，ASP/ASP.NET）",
    "charunicodeescape": "Unicode 转义编码（\\u0027 形式，JSON场景）",
    "commalesslimit": "LIMIT M,N → LIMIT N OFFSET M（MySQL）",
    "commalessmid": "MID(A,B,C) → MID(A FROM B FOR C)（MySQL）",
    "commentbeforeparentheses": "括号前插入注释",
    "concat2concatws": "CONCAT(A,B) → CONCAT_WS(CHAR(0),A,B)（MySQL）",
    "decentities": "HTML 十进制实体编码",
    "dunion": "UNION → DUNION（Oracle）",
    "equaltolike": "= → LIKE（注意 LIKE 的模式匹配语义）",
    "equaltorlike": "= → RLIKE/REGEXP（MySQL）",
    "escapequotes": "反斜杠转义引号",
    "greatest": "> → GREATEST（均针对 > 运算符）",
    "halfversionedmorekeywords": "在每个关键字前添加 MySQL 版本注释",
    "hex2char": "0x<hex> → CONCAT(CHAR(),...)（MySQL）",
    "hexentities": "HTML 十六进制实体编码",
    "htmlencode": "HTML 实体编码",
    "if2case": "IF(A,B,C) → CASE WHEN A THEN B ELSE C END（MySQL）",
    "ifnull2casewhenisnull": "IFNULL(A,B) → CASE WHEN ISNULL(A) THEN B ELSE A END",
    "ifnull2ifisnull": "IFNULL(A,B) → IF(ISNULL(A), B, A)",
    "informationschemacomment": "information_schema 后加注释绕过",
    "least": "> → LEAST（均针对 > 运算符）",
    "lowercase": "关键字转小写",
    "luanginx": "[第三方] Lua-Nginx WAF 绕过（如 Cloudflare）",
    "luanginxmore": "[第三方] Lua-Nginx WAF 加强绕过",
    "misunion": "UNION → -.1UNION（MySQL）",
    "modsecurityversioned": "用 MySQL 版本注释 /*!...*/ 包围查询",
    "modsecurityzeroversioned": "用 MySQL 零版本注释 /*!00000 ...*/ 包围查询",
    "multiplespaces": "多空格绕过关键字检测",
    "ord2ascii": "ORD() → ASCII()（MySQL）",
    "overlongutf8": "UTF-8 超长编码绕过",
    "overlongutf8more": "UTF-8 超长编码加强版",
    "percentage": "每个字符前加 %%（ASP 环境）",
    "plus2concat": "+ → CONCAT() 函数（MSSQL）",
    "plus2fnconcat": "+ → {fn CONCAT()} ODBC 函数（MSSQL）",
    "randomcase": "关键字大小写随机化",
    "randomcomments": "关键字间随机插入注释",
    "schemasplit": "schema 名拆分绕过",
    "scientific": "科学计数法绕过数字检测",
    "sleep2getlock": "SLEEP → GET_LOCK（MySQL）",
    "sp_password": "MSSQL sp_password 日志隐藏绕过",
    "space2comment": "空格 → /**/ 注释",
    "space2dash": "空格 → -- 注释+换行（MSSQL/PostgreSQL）",
    "space2hash": "空格 → # 注释+换行（MySQL）",
    "space2morecomment": "空格 → 更多注释",
    "space2morehash": "空格 → 更多 # 注释",
    "space2mssqlblank": "空格 → MSSQL 空白字符",
    "space2mssqlhash": "空格 → MSSQL %23%0A",
    "space2mysqlblank": "空格 → MySQL 空白字符",
    "space2mysqldash": "空格 → MySQL -- 注释",
    "space2plus": "空格 → + 加号",
    "space2randomblank": "空格 → 随机空白字符",
    "substring2leftright": "SUBSTRING → LEFT/RIGHT",
    "symboliclogical": "AND/OR → &&/|| 符号",
    "unionalltounion": "UNION ALL → UNION",
    "unmagicquotes": "宽字节注入（%df%27 绕过 addslashes）",
    "uppercase": "关键字转大写",
    "varnish": "Varnish 缓存/WAF 绕过",
    "versionedkeywords": "MySQL 版本注释关键字绕过",
    "versionedmorekeywords": "MySQL 版本注释加强版",
    "xforwardedfor": "添加伪造的 X-Forwarded-For / X-Client-Ip 等头，随机 IP",
}


class SqlmapGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("sqlmap GUI - SQL注入渗透测试工具")
        self.root.geometry("1100x750")
        self.root.minsize(900, 600)

        # 进程相关（终端模式下GUI不直接管理进程）
        # （保留占位，如需内置运行模式可恢复）

        # 样式配置
        self._setup_style()

        # Tooltip 窗口（tamper 悬停提示）
        self._tooltip_win = None
        self._tooltip_script = None

        # 构建界面
        self._build_menu()
        self._build_toolbar()
        self._build_notebook()
        self._build_output_panel()
        self._build_statusbar()

        # Python 路径（默认为空，使用当前解释器）
        self.python_path = ""

        # 加载配置
        self._load_config()

    # ============================================================
    # 样式
    # ============================================================
    def _setup_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except:
            pass

        # 现代深色主题配色
        self.bg_color = "#0f172a"           # 最深背景
        self.panel_color = "#1e293b"        # 面板背景
        self.panel_light = "#334155"        # 稍亮的面板
        self.accent_color = "#3b82f6"       # 主色调 - 蓝色
        self.accent_hover = "#60a5fa"       # 悬停蓝
        self.accent_pressed = "#2563eb"     # 按下蓝
        self.success_color = "#10b981"      # 成功绿
        self.warning_color = "#f59e0b"      # 警告橙
        self.danger_color = "#ef4444"       # 危险红
        self.text_color = "#f1f5f9"         # 主文字
        self.text_secondary = "#94a3b8"     # 次要文字
        self.text_muted = "#64748b"         # 弱化文字
        self.border_color = "#475569"       # 边框
        self.border_light = "#334155"       # 浅边框

        self.root.configure(bg=self.bg_color)

        # Notebook样式
        style.configure("TNotebook", background=self.bg_color, borderwidth=0)
        style.configure("TNotebook.Tab", padding=[22, 12], font=("Microsoft YaHei", 10, "bold"),
                        background=self.panel_color, foreground=self.text_secondary)
        style.map("TNotebook.Tab",
                  background=[("selected", self.accent_color)],
                  foreground=[("selected", "white")],
                  )

        # Frame
        style.configure("TFrame", background=self.panel_color)

        # Label
        style.configure("TLabel", background=self.panel_color, foreground=self.text_color, font=("Microsoft YaHei", 9))
        style.configure("Title.TLabel", background=self.panel_color, foreground=self.text_color,
                        font=("Microsoft YaHei", 14, "bold"))
        style.configure("SubTitle.TLabel", background=self.panel_color, foreground=self.text_secondary,
                        font=("Microsoft YaHei", 9))

        # Button
        style.configure("TButton", font=("Microsoft YaHei", 9), padding=[18, 8],
                        background=self.panel_light, foreground=self.text_color,
                        borderwidth=0, focusthickness=0)
        style.map("TButton",
                  background=[("active", "#475569"), ("pressed", "#64748b")],
                  foreground=[("active", "white")])

        # Accent Button
        style.configure("Accent.TButton", background=self.accent_color, foreground="white",
                        font=("Microsoft YaHei", 10, "bold"), padding=[20, 10],
                        borderwidth=0, focusthickness=0)
        style.map("Accent.TButton",
                  background=[("active", self.accent_hover), ("pressed", self.accent_pressed)],
                  foreground=[("active", "white")])

        # Danger Button
        style.configure("Danger.TButton", background=self.danger_color, foreground="white",
                        font=("Microsoft YaHei", 10, "bold"), padding=[20, 10],
                        borderwidth=0, focusthickness=0)
        style.map("Danger.TButton",
                  background=[("active", "#f87171"), ("pressed", "#dc2626")],
                  foreground=[("active", "white")])

        # Success Button
        style.configure("Success.TButton", background=self.success_color, foreground="white",
                        font=("Microsoft YaHei", 10, "bold"), padding=[20, 10],
                        borderwidth=0, focusthickness=0)
        style.map("Success.TButton",
                  background=[("active", "#34d399"), ("pressed", "#059669")],
                  foreground=[("active", "white")])

        # Entry
        style.configure("TEntry", fieldbackground="#0f172a", foreground=self.text_color,
                        bordercolor=self.border_color, lightcolor=self.border_color,
                        darkcolor=self.border_color, padding=6, borderwidth=1)
        style.map("TEntry",
                  bordercolor=[("focus", self.accent_color)],
                  lightcolor=[("focus", self.accent_color)],
                  darkcolor=[("focus", self.accent_color)])

        # Combobox
        style.configure("TCombobox", fieldbackground="#0f172a", foreground=self.text_color,
                        background=self.panel_light, bordercolor=self.border_color,
                        arrowcolor=self.text_color, padding=5)
        style.map("TCombobox",
                  fieldbackground=[("readonly", "#0f172a")],
                  foreground=[("readonly", self.text_color)])

        # Spinbox
        style.configure("TSpinbox", fieldbackground="#0f172a", foreground=self.text_color,
                        bordercolor=self.border_color, arrowsize=14, padding=4)

        # Labelframe
        style.configure("TLabelframe", background=self.panel_color, bordercolor=self.border_color,
                        relief="groove", borderwidth=1)
        style.configure("TLabelframe.Label", background=self.panel_color,
                        foreground=self.accent_color, font=("Microsoft YaHei", 10, "bold"))

        # Checkbutton
        style.configure("TCheckbutton", background=self.panel_color, foreground=self.text_color,
                        font=("Microsoft YaHei", 9), focusthickness=0)
        style.map("TCheckbutton",
                  background=[("active", self.panel_color)],
                  foreground=[("active", self.accent_hover)])

        # Radiobutton
        style.configure("TRadiobutton", background=self.panel_color, foreground=self.text_color,
                        font=("Microsoft YaHei", 9), focusthickness=0)
        style.map("TRadiobutton",
                  background=[("active", self.panel_color)])

        # Progressbar
        style.configure("Horizontal.TProgressbar", background=self.accent_color,
                        troughcolor=self.panel_light, bordercolor=self.panel_light,
                        lightcolor=self.accent_color, darkcolor=self.accent_color,
                        thickness=6)

        # Scrollbar
        style.configure("Vertical.TScrollbar", background=self.panel_light,
                        troughcolor=self.panel_color, bordercolor=self.panel_color,
                        arrowcolor=self.text_secondary, width=10)
        style.map("Vertical.TScrollbar",
                  background=[("active", self.accent_color)])

        style.configure("Horizontal.TScrollbar", background=self.panel_light,
                        troughcolor=self.panel_color, bordercolor=self.panel_color,
                        arrowcolor=self.text_secondary, height=10)
        style.map("Horizontal.TScrollbar",
                  background=[("active", self.accent_color)])

        # Menubutton
        style.configure("TMenubutton", background=self.panel_light, foreground=self.text_color,
                        font=("Microsoft YaHei", 9), padding=[10, 5], borderwidth=0)
        style.map("TMenubutton",
                  background=[("active", "#475569")])

    # ============================================================
    # 菜单栏
    # ============================================================
    def _build_menu(self):
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        # 文件菜单
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="文件", menu=file_menu)
        file_menu.add_command(label="加载配置...", command=self._load_config_dialog)
        file_menu.add_command(label="保存配置...", command=self._save_config_dialog)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self._on_close)

        # 工具菜单
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="工具", menu=tools_menu)
        tools_menu.add_command(label="打开输出目录", command=self._open_output_dir)
        tools_menu.add_separator()
        tools_menu.add_command(label="Python 路径设置...", command=self._set_python_path)

        # 帮助菜单
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="帮助", menu=help_menu)
        help_menu.add_command(label="关于", command=self._show_about)

    # ============================================================
    # 工具栏
    # ============================================================
    def _build_toolbar(self):
        toolbar = tk.Frame(self.root, bg=self.panel_color, height=90,
                           highlightthickness=1, highlightbackground=self.border_light)
        toolbar.pack(fill="x", side="top")
        toolbar.pack_propagate(False)

        # 左侧Logo/标题区域
        logo_frame = tk.Frame(toolbar, bg=self.panel_color)
        logo_frame.pack(side="left", padx=(20, 10), pady=16)
        tk.Label(logo_frame, text="⚡", bg=self.panel_color, fg=self.accent_color,
                 font=("Segoe UI Emoji", 20)).pack(side="left", padx=(0, 8))
        tk.Label(logo_frame, text="sqlmap GUI", bg=self.panel_color, fg="white",
                 font=("Microsoft YaHei", 13, "bold")).pack(side="left")
        tk.Label(logo_frame, text="v0.1", bg=self.panel_color, fg=self.text_muted,
                 font=("Microsoft YaHei", 9)).pack(side="left", padx=(6, 0))

        # 分隔线
        tk.Frame(toolbar, width=1, bg=self.border_light).pack(side="left", fill="y", padx=10, pady=16)

        # 开始按钮
        self.start_btn = tk.Button(
            toolbar, text="  ▶  开始扫描  ", bg=self.success_color, fg="white",
            font=("Microsoft YaHei", 10, "bold"), relief="flat",
            padx=10, pady=10, cursor="hand2", command=self._start_scan,
            activebackground="#34d399", activeforeground="white",
            bd=0, borderwidth=0
        )
        self.start_btn.pack(side="left", padx=10, pady=22)

        # 停止按钮
        self.stop_btn = tk.Button(
            toolbar, text="  ■  停止  ", bg=self.danger_color, fg="white",
            font=("Microsoft YaHei", 10, "bold"), relief="flat",
            padx=10, pady=10, cursor="hand2", command=self._stop_scan, state="disabled",
            activebackground="#f87171", activeforeground="white",
            bd=0, borderwidth=0
        )
        self.stop_btn.pack(side="left", padx=(0, 10), pady=22)

        # 分隔线
        tk.Frame(toolbar, width=1, bg=self.border_light).pack(side="left", fill="y", padx=10, pady=16)

        # 命令预览区域
        preview_frame = tk.Frame(toolbar, bg=self.panel_color)
        preview_frame.pack(side="left", fill="x", expand=True, padx=(5, 20), pady=10)

        tk.Label(preview_frame, text="命令预览", bg=self.panel_color, fg=self.text_secondary,
                 font=("Microsoft YaHei", 9, "bold")).pack(anchor="w")

        self.cmd_preview_var = tk.StringVar(value="python sqlmap.py -u <target>")
        cmd_preview = tk.Entry(
            preview_frame, textvariable=self.cmd_preview_var,
            bg="#0f172a", fg="#34d399", font=("Consolas", 12, "bold"),
            relief="flat", readonlybackground="#0f172a", state="readonly",
            insertbackground=self.accent_color, highlightthickness=1,
            highlightbackground="#475569", highlightcolor=self.accent_color
        )
        cmd_preview.pack(fill="x", pady=(6, 0), ipady=10)

    # ============================================================
    # 标签页
    # ============================================================
    def _build_notebook(self):
        notebook_frame = tk.Frame(self.root, bg=self.bg_color)
        notebook_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.notebook = ttk.Notebook(notebook_frame)
        self.notebook.pack(fill="both", expand=True)

        # 各标签页
        self._build_target_tab()
        self._build_request_tab()
        self._build_injection_tab()
        self._build_enumeration_tab()
        self._build_advanced_tab()

    # ---------------- 目标标签页 ----------------
    def _build_target_tab(self):
        tab = tk.Frame(self.notebook, bg=self.panel_color)
        self.notebook.add(tab, text="  🎯 目标  ")

        # 目标URL
        group1 = tk.LabelFrame(tab, text=" 目标地址 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group1.pack(fill="x", padx=20, pady=(20, 10))

        tk.Label(group1, text="目标 URL:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="w", pady=5)
        self.target_url = tk.StringVar()
        url_entry = tk.Entry(group1, textvariable=self.target_url, font=("Consolas", 10),
                             relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6")
        url_entry.grid(row=0, column=1, sticky="ew", padx=10, pady=5)
        url_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group1, text="例如: http://example.com/page.php?id=1", bg=self.panel_color,
                 fg="#64748b", font=("Microsoft YaHei", 8)).grid(row=1, column=1, sticky="w", padx=10)

        group1.grid_columnconfigure(1, weight=1)

        # 请求方法
        group2 = tk.LabelFrame(tab, text=" 请求方式 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group2.pack(fill="x", padx=20, pady=10)

        self.request_method = tk.StringVar(value="GET")
        methods = ["GET", "POST", "PUT", "DELETE", "PATCH"]
        for i, method in enumerate(methods):
            tk.Radiobutton(group2, text=method, variable=self.request_method, value=method,
                           bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                           activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                           ).grid(row=0, column=i, padx=15, pady=5)

        # POST数据
        tk.Label(group2, text="POST 数据:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="w", pady=(15, 5))
        self.post_data = tk.StringVar()
        post_entry = tk.Entry(group2, textvariable=self.post_data, font=("Consolas", 10),
                              relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6")
        post_entry.grid(row=1, column=1, columnspan=4, sticky="ew", padx=10, pady=(15, 5))
        post_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group2, text="例如: username=admin&password=123", bg=self.panel_color,
                 fg="#64748b", font=("Microsoft YaHei", 8)).grid(row=2, column=1, sticky="w", padx=10)

        group2.grid_columnconfigure(1, weight=1)

        # Cookie
        group3 = tk.LabelFrame(tab, text=" Cookie ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group3.pack(fill="x", padx=20, pady=10)

        tk.Label(group3, text="Cookie:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="w", pady=5)
        self.cookie = tk.StringVar()
        cookie_entry = tk.Entry(group3, textvariable=self.cookie, font=("Consolas", 10),
                                relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6")
        cookie_entry.grid(row=0, column=1, sticky="ew", padx=10, pady=5)
        cookie_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        group3.grid_columnconfigure(1, weight=1)

        # 快速常用选项
        group4 = tk.LabelFrame(tab, text=" 快捷选项 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group4.pack(fill="x", padx=20, pady=10)

        self.batch_mode = tk.BooleanVar(value=False)
        tk.Checkbutton(group4, text="批处理模式 (--batch)", variable=self.batch_mode,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        self.random_agent = tk.BooleanVar(value=False)
        tk.Checkbutton(group4, text="随机 User-Agent (--random-agent)", variable=self.random_agent,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=1, sticky="w", padx=20, pady=5)

        self.ignore_redirects = tk.BooleanVar(value=False)
        tk.Checkbutton(group4, text="忽略重定向 (--ignore-redirects)", variable=self.ignore_redirects,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=0, sticky="w", padx=10, pady=5)

        self.skip_waf = tk.BooleanVar(value=False)
        tk.Checkbutton(group4, text="跳过WAF检测 (--skip-waf)", variable=self.skip_waf,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=1, sticky="w", padx=20, pady=5)

        self.delay_var = tk.StringVar(value="0")
        tk.Label(group4, text="请求延迟(秒):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=2, column=1, sticky="w", padx=20, pady=5)
        delay_entry = tk.Entry(group4, textvariable=self.delay_var, width=8, font=("Consolas", 9),
                               relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6")
        delay_entry.grid(row=2, column=1, sticky="e", padx=10, pady=5)
        delay_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

    # ---------------- 请求标签页 ----------------
    def _build_request_tab(self):
        tab = tk.Frame(self.notebook, bg=self.panel_color)
        self.notebook.add(tab, text="  📡 请求  ")

        # Headers
        group1 = tk.LabelFrame(tab, text=" HTTP Header ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group1.pack(fill="both", expand=True, padx=20, pady=(20, 10))

        tk.Label(group1, text="自定义 Headers:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="nw", pady=5)
        self.headers_text = tk.Text(group1, height=5, font=("Consolas", 9), relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6")
        self.headers_text.grid(row=0, column=1, sticky="ew", padx=10, pady=5)
        self.headers_text.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group1, text="每行一个，格式: Header-Name: value", bg=self.panel_color,
                 fg="#64748b", font=("Microsoft YaHei", 8)).grid(row=1, column=1, sticky="w", padx=10)

        group1.grid_columnconfigure(1, weight=1)

        # 代理
        group2 = tk.LabelFrame(tab, text=" 代理设置 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group2.pack(fill="x", padx=20, pady=10)

        self.use_proxy = tk.BooleanVar(value=False)
        tk.Checkbutton(group2, text="使用代理", variable=self.use_proxy,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        tk.Label(group2, text="代理地址:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=1, sticky="e", pady=5)
        self.proxy_addr = tk.StringVar(value="http://127.0.0.1:8080")
        proxy_entry = tk.Entry(group2, textvariable=self.proxy_addr, font=("Consolas", 9),
                               relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=30)
        proxy_entry.grid(row=0, column=2, sticky="w", padx=10, pady=5)
        proxy_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group2, text="线程数:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="e", padx=10, pady=5)
        self.threads = tk.StringVar(value="1")
        threads_spin = tk.Spinbox(group2, from_=1, to=50, textvariable=self.threads, width=8,
                                  font=("Consolas", 9), relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", buttonbackground="#334155",
                                  command=self._update_cmd_preview)
        threads_spin.grid(row=1, column=1, sticky="w", padx=10, pady=5)
        threads_spin.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group2, text="超时(秒):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=2, sticky="e", pady=5)
        self.timeout = tk.StringVar(value="30")
        timeout_spin = tk.Spinbox(group2, from_=5, to=300, textvariable=self.timeout, width=8,
                                  font=("Consolas", 9), relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", buttonbackground="#334155",
                                  command=self._update_cmd_preview)
        timeout_spin.grid(row=1, column=3, sticky="w", padx=10, pady=5)
        timeout_spin.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        # 其他请求选项
        group3 = tk.LabelFrame(tab, text=" 其他选项 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group3.pack(fill="x", padx=20, pady=10)

        self.ignore_proxy = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="忽略系统代理 (--ignore-proxy)", variable=self.ignore_proxy,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        self.tor_mode = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="Tor 匿名网络 (--tor)", variable=self.tor_mode,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=1, sticky="w", padx=20, pady=5)

        self.force_ssl = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="强制SSL (--force-ssl)", variable=self.force_ssl,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=0, sticky="w", padx=10, pady=5)

        self.no_cast = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="关闭字符编码 (--no-cast)", variable=self.no_cast,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=1, sticky="w", padx=20, pady=5)

    # ---------------- 注入标签页 ----------------
    def _build_injection_tab(self):
        tab = tk.Frame(self.notebook, bg=self.panel_color)
        self.notebook.add(tab, text="  💉 注入  ")

        # 测试参数
        group1 = tk.LabelFrame(tab, text=" 注入参数 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group1.pack(fill="x", padx=20, pady=(20, 10))

        tk.Label(group1, text="测试参数:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="w", pady=5)
        self.test_param = tk.StringVar(value="")
        param_entry = tk.Entry(group1, textvariable=self.test_param, font=("Consolas", 10),
                               relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=30)
        param_entry.grid(row=0, column=1, sticky="w", padx=10, pady=5)
        param_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())
        tk.Label(group1, text="留空=全部参数", bg=self.panel_color, fg="#64748b", font=("Microsoft YaHei", 8)).grid(row=0, column=2, sticky="w", padx=5)

        tk.Label(group1, text="DBMS类型:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="w", pady=5)
        self.dbms_type = tk.StringVar(value="自动识别")
        dbms_combo = ttk.Combobox(group1, textvariable=self.dbms_type, state="readonly", width=25,
                                  values=["自动识别", "MySQL", "PostgreSQL", "Microsoft SQL Server",
                                          "Oracle", "SQLite", "Microsoft Access", "MongoDB", "Redis"])
        dbms_combo.grid(row=1, column=1, sticky="w", padx=10, pady=5)
        dbms_combo.bind("<<ComboboxSelected>>", lambda e: self._update_cmd_preview())

        tk.Label(group1, text="操作系统:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=2, column=0, sticky="w", pady=5)
        self.os_type = tk.StringVar(value="自动识别")
        os_combo = ttk.Combobox(group1, textvariable=self.os_type, state="readonly", width=25,
                                values=["自动识别", "Linux", "Windows"])
        os_combo.grid(row=2, column=1, sticky="w", padx=10, pady=5)
        os_combo.bind("<<ComboboxSelected>>", lambda e: self._update_cmd_preview())

        # 等级和风险
        group2 = tk.LabelFrame(tab, text=" 等级与风险 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group2.pack(fill="x", padx=20, pady=10)

        tk.Label(group2, text="测试等级 (level):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="w", pady=5)
        self.level_var = tk.IntVar(value=1)
        level_frame = tk.Frame(group2, bg=self.panel_color)
        level_frame.grid(row=0, column=1, sticky="w", padx=10, pady=5)
        for i in range(1, 6):
            tk.Radiobutton(level_frame, text=str(i), variable=self.level_var, value=i,
                           bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                           activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                           ).pack(side="left", padx=8)

        tk.Label(group2, text="风险等级 (risk):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="w", pady=5)
        self.risk_var = tk.IntVar(value=1)
        risk_frame = tk.Frame(group2, bg=self.panel_color)
        risk_frame.grid(row=1, column=1, sticky="w", padx=10, pady=5)
        for i in range(1, 4):
            tk.Radiobutton(risk_frame, text=str(i), variable=self.risk_var, value=i,
                           bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                           activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                           ).pack(side="left", padx=8)

        # 注入技术
        group3 = tk.LabelFrame(tab, text=" 注入技术 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group3.pack(fill="x", padx=20, pady=10)

        self.tech_be = tk.BooleanVar(value=True)   # B - Boolean-based blind
        self.tech_e = tk.BooleanVar(value=True)    # E - Error-based
        self.tech_u = tk.BooleanVar(value=True)    # U - Union query
        self.tech_s = tk.BooleanVar(value=True)    # S - Stacked queries
        self.tech_t = tk.BooleanVar(value=True)    # T - Time-based blind
        self.tech_q = tk.BooleanVar(value=True)    # Q - Inline queries

        techs = [
            ("布尔盲注 B", self.tech_be),
            ("报错注入 E", self.tech_e),
            ("联合查询 U", self.tech_u),
            ("堆叠查询 S", self.tech_s),
            ("时间盲注 T", self.tech_t),
            ("内联查询 Q", self.tech_q),
        ]

        for i, (label, var) in enumerate(techs):
            tk.Checkbutton(group3, text=label, variable=var,
                           bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                           activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                           ).grid(row=i // 3, column=i % 3, sticky="w", padx=15, pady=5)

        # Tamper 脚本
        group4 = tk.LabelFrame(tab, text=" Tamper 脚本 (WAF绕过) ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group4.pack(fill="both", expand=True, padx=20, pady=10)

        # 列出可用tamper脚本
        tamper_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sqlmap", "tamper")
        tamper_scripts = []
        try:
            for f in os.listdir(tamper_dir):
                if f.endswith(".py") and f != "__init__.py":
                    tamper_scripts.append(f.replace(".py", ""))
            tamper_scripts.sort()
        except:
            tamper_scripts = ["space2comment", "space2dash", "space2hash", "randomcase",
                              "charencode", "chardoubleencode", "base64encode", "unmagicquotes"]

        self.tamper_listbox = tk.Listbox(group4, selectmode="multiple", height=8,
                                         font=("Consolas", 9), relief="flat",
                                         bg="#0f172a", fg="#f1f5f9", selectforeground="white", selectbackground=self.accent_color, highlightthickness=1, highlightbackground="#475569")
        self.tamper_listbox.pack(side="left", fill="both", expand=True, padx=(10, 5), pady=5)
        for script in tamper_scripts:
            self.tamper_listbox.insert("end", script)
        self.tamper_listbox.bind("<<ListboxSelect>>", lambda e: self._update_cmd_preview())
        self.tamper_listbox.bind("<Motion>", self._on_tamper_hover)
        self.tamper_listbox.bind("<Leave>", self._hide_tamper_tooltip)

        scrollbar = tk.Scrollbar(group4, orient="vertical", command=self.tamper_listbox.yview, bg="#334155", troughcolor="#1e293b", activebackground="#3b82f6", width=12, relief="flat")
        scrollbar.pack(side="left", fill="y", pady=5)
        self.tamper_listbox.config(yscrollcommand=scrollbar.set)

        tk.Label(group4, text="💡 悬停查看说明  |  按住 Ctrl 多选", bg=self.panel_color, fg="#64748b",
                 font=("Microsoft YaHei", 8)).pack(side="bottom", anchor="w", padx=10, pady=(5, 0))

    # ---------------- 枚举标签页 ----------------
    def _build_enumeration_tab(self):
        tab = tk.Frame(self.notebook, bg=self.panel_color)
        self.notebook.add(tab, text="  📊 枚举  ")

        # 枚举选项
        group1 = tk.LabelFrame(tab, text=" 数据枚举 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group1.pack(fill="x", padx=20, pady=(20, 10))

        self.enum_banner = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="获取 Banner (--banner)", variable=self.enum_banner,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        self.enum_current_user = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="当前用户 (--current-user)", variable=self.enum_current_user,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=1, sticky="w", padx=20, pady=5)

        self.enum_current_db = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="当前数据库 (--current-db)", variable=self.enum_current_db,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=2, sticky="w", padx=20, pady=5)

        self.enum_dbs = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="所有数据库 (--dbs)", variable=self.enum_dbs,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=0, sticky="w", padx=10, pady=5)

        self.enum_tables = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="所有表 (--tables)", variable=self.enum_tables,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=1, sticky="w", padx=20, pady=5)

        self.enum_columns = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="所有列 (--columns)", variable=self.enum_columns,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=2, sticky="w", padx=20, pady=5)

        self.enum_dump = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="Dump 所有数据 (--dump)", variable=self.enum_dump,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=2, column=0, sticky="w", padx=10, pady=5)

        self.enum_dump_all = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="Dump 全部数据库 (--dump-all)", variable=self.enum_dump_all,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=2, column=1, sticky="w", padx=20, pady=5)

        self.enum_passwords = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="密码哈希 (--passwords)", variable=self.enum_passwords,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=2, column=2, sticky="w", padx=20, pady=5)

        self.enum_users = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="所有用户 (--users)", variable=self.enum_users,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=3, column=0, sticky="w", padx=10, pady=5)

        self.enum_privileges = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="用户权限 (--privileges)", variable=self.enum_privileges,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=3, column=1, sticky="w", padx=20, pady=5)

        self.enum_roles = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="用户角色 (--roles)", variable=self.enum_roles,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=3, column=2, sticky="w", padx=20, pady=5)

        # 指定枚举
        group2 = tk.LabelFrame(tab, text=" 指定枚举 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group2.pack(fill="x", padx=20, pady=10)

        tk.Label(group2, text="指定数据库 (-D):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="w", pady=5)
        self.enum_db = tk.StringVar()
        db_entry = tk.Entry(group2, textvariable=self.enum_db, font=("Consolas", 9),
                            relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=25)
        db_entry.grid(row=0, column=1, sticky="w", padx=10, pady=5)
        db_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group2, text="指定表 (-T):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=2, sticky="e", pady=5)
        self.enum_table = tk.StringVar()
        table_entry = tk.Entry(group2, textvariable=self.enum_table, font=("Consolas", 9),
                               relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=25)
        table_entry.grid(row=0, column=3, sticky="w", padx=10, pady=5)
        table_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group2, text="指定列 (-C):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="w", pady=5)
        self.enum_column = tk.StringVar()
        col_entry = tk.Entry(group2, textvariable=self.enum_column, font=("Consolas", 9),
                             relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=25)
        col_entry.grid(row=1, column=1, sticky="w", padx=10, pady=5)
        col_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group2, text="WHERE条件 (--where):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=2, sticky="e", pady=5)
        self.enum_where = tk.StringVar()
        where_entry = tk.Entry(group2, textvariable=self.enum_where, font=("Consolas", 9),
                               relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=25)
        where_entry.grid(row=1, column=3, sticky="w", padx=10, pady=5)
        where_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        # 文件系统和操作系统访问
        group3 = tk.LabelFrame(tab, text=" 文件系统 / 操作系统 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group3.pack(fill="x", padx=20, pady=10)

        self.file_read = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="读取文件 (--file-read)", variable=self.file_read,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        self.file_read_path = tk.StringVar()
        tk.Entry(group3, textvariable=self.file_read_path, font=("Consolas", 9),
                 relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=45).grid(row=0, column=1, columnspan=4, sticky="w", padx=5, pady=5)
        tk.Label(group3, text="(远程文件路径)", bg=self.panel_color, fg="#64748b", font=("Microsoft YaHei", 8)).grid(row=0, column=5, padx=2)

        self.file_write = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="写入文件 (--file-write)", variable=self.file_write,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=0, sticky="w", padx=10, pady=5)

        self.file_write_src = tk.StringVar()
        tk.Entry(group3, textvariable=self.file_write_src, font=("Consolas", 9),
                 relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=20).grid(row=1, column=1, sticky="w", padx=5, pady=5)
        tk.Button(group3, text="源文件...", font=("Microsoft YaHei", 8), relief="flat",
                  bg="#334155", fg="#f1f5f9", activebackground="#475569", activeforeground="white", cursor="hand2",
                  command=lambda: self._choose_local_file(self.file_write_src, "选择本地源文件")
                  ).grid(row=1, column=2, padx=2, pady=5)
        tk.Label(group3, text="→", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=3, padx=2)
        self.file_write_dest = tk.StringVar()
        tk.Entry(group3, textvariable=self.file_write_dest, font=("Consolas", 9),
                 relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=20).grid(row=1, column=4, sticky="w", padx=5, pady=5)
        tk.Label(group3, text="(目标路径)", bg=self.panel_color, fg="#64748b", font=("Microsoft YaHei", 8)).grid(row=1, column=5, padx=2)

        self.os_shell = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="交互式Shell (--os-shell)", variable=self.os_shell,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=2, column=0, sticky="w", padx=10, pady=5)

        self.os_cmd = tk.StringVar()
        tk.Label(group3, text="执行命令 (--os-cmd):", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=2, column=2, sticky="e", pady=5)
        cmd_entry = tk.Entry(group3, textvariable=self.os_cmd, font=("Consolas", 9),
                             relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=25)
        cmd_entry.grid(row=2, column=3, sticky="w", padx=10, pady=5)
        cmd_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

    # ---------------- 高级标签页 ----------------
    def _build_advanced_tab(self):
        tab = tk.Frame(self.notebook, bg=self.panel_color)
        self.notebook.add(tab, text="  ⚙️ 高级  ")

        # 检测选项
        group1 = tk.LabelFrame(tab, text=" 检测选项 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group1.pack(fill="x", padx=20, pady=(20, 10))

        self.forms = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="自动解析表单 (--forms)", variable=self.forms,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        self.crawl = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="爬虫模式 (--crawl)", variable=self.crawl,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=1, sticky="w", padx=20, pady=5)

        self.crawl_depth = tk.StringVar(value="2")
        tk.Label(group1, text="爬虫深度:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=0, column=2, sticky="e", pady=5)
        crawl_spin = tk.Spinbox(group1, from_=1, to=10, textvariable=self.crawl_depth, width=6,
                                font=("Consolas", 9), relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", buttonbackground="#334155",
                                command=self._update_cmd_preview)
        crawl_spin.grid(row=0, column=3, sticky="w", padx=5, pady=5)

        self.csrf = tk.BooleanVar(value=False)
        csrf_frame = tk.Frame(group1, bg=self.panel_color)
        csrf_frame.grid(row=1, column=0, sticky="w", padx=10, pady=5)
        tk.Checkbutton(csrf_frame, text="绕过CSRF", variable=self.csrf,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).pack(side="left")
        tk.Label(csrf_frame, text="Token名:", bg=self.panel_color, fg=self.text_secondary,
                 font=("Microsoft YaHei", 8)).pack(side="left", padx=(10, 2))
        self.csrf_token_name = tk.StringVar(value="")
        csrf_entry = tk.Entry(csrf_frame, textvariable=self.csrf_token_name, width=18,
                              font=("Consolas", 9), relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6")
        csrf_entry.pack(side="left")
        csrf_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())
        tk.Label(csrf_frame, text="(留空自动检测)", bg=self.panel_color, fg="#64748b",
                 font=("Microsoft YaHei", 8)).pack(side="left", padx=(5, 0))

        self.skip_heuristic = tk.BooleanVar(value=False)
        tk.Checkbutton(group1, text="跳过启发式检测 (--skip-heuristics)", variable=self.skip_heuristic,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=1, sticky="w", padx=20, pady=5)

        tk.Checkbutton(group1, text="跳过WAF检测 (--skip-waf)", variable=self.skip_waf,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=2, sticky="w", padx=20, pady=5)

        # 暴力破解
        group2 = tk.LabelFrame(tab, text=" 暴力破解 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group2.pack(fill="x", padx=20, pady=10)

        self.common_tables = tk.BooleanVar(value=False)
        tk.Checkbutton(group2, text="常见表名 (--common-tables)", variable=self.common_tables,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        self.common_columns = tk.BooleanVar(value=False)
        tk.Checkbutton(group2, text="常见列名 (--common-columns)", variable=self.common_columns,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=1, sticky="w", padx=20, pady=5)

        self.common_files = tk.BooleanVar(value=False)
        tk.Checkbutton(group2, text="常见文件 (--common-files)", variable=self.common_files,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=0, sticky="w", padx=10, pady=5)

        self.eta_show = tk.BooleanVar(value=False)
        tk.Checkbutton(group2, text="显示ETA (--eta)", variable=self.eta_show,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=1, column=1, sticky="w", padx=20, pady=5)

        # 其他
        group3 = tk.LabelFrame(tab, text=" 其他高级选项 ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group3.pack(fill="x", padx=20, pady=10)

        self.hex_convert = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="十六进制转换 (--hex)", variable=self.hex_convert,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=0, sticky="w", padx=10, pady=5)

        self.optimize = tk.BooleanVar(value=False)
        tk.Checkbutton(group3, text="性能优化 (-o)", variable=self.optimize,
                       bg=self.panel_color, fg="#f1f5f9", selectcolor="#0f172a", font=("Microsoft YaHei", 9),
                       activebackground=self.panel_color, activeforeground="#60a5fa", command=self._update_cmd_preview
                       ).grid(row=0, column=1, sticky="w", padx=20, pady=5)

        self.output_dir = tk.StringVar(value=DEFAULT_OUTPUT_DIR)
        tk.Label(group3, text="输出目录:", bg=self.panel_color, fg=self.text_color, font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="w", pady=5)
        out_entry = tk.Entry(group3, textvariable=self.output_dir, font=("Consolas", 9),
                             relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6", width=40)
        out_entry.grid(row=1, column=1, columnspan=2, sticky="ew", padx=10, pady=5)
        tk.Button(group3, text="浏览...", font=("Microsoft YaHei", 9), relief="flat",
                  bg="#334155", fg="#f1f5f9", activebackground="#475569", activeforeground="white", cursor="hand2", command=self._choose_output_dir
                  ).grid(row=1, column=3, padx=5, pady=5)

        # 自定义参数
        group4 = tk.LabelFrame(tab, text=" 自定义参数 (直接附加到命令) ", bg=self.panel_color, fg=self.text_color,
                               font=("Microsoft YaHei", 10, "bold"), padx=15, pady=10, relief="groove", bd=1)
        group4.pack(fill="both", expand=True, padx=20, pady=10)

        self.custom_args = tk.StringVar()
        custom_entry = tk.Entry(group4, textvariable=self.custom_args, font=("Consolas", 10),
                                relief="flat", bg="#0f172a", fg="#f1f5f9", insertbackground="#3b82f6", highlightthickness=1, highlightbackground="#475569", highlightcolor="#3b82f6")
        custom_entry.pack(fill="x", padx=10, pady=5)
        custom_entry.bind("<KeyRelease>", lambda e: self._update_cmd_preview())

        tk.Label(group4, text="例如: --no-cast --answers=\"follow=N\"", bg=self.panel_color,
                 fg="#64748b", font=("Microsoft YaHei", 8)).pack(anchor="w", padx=10)

    # ============================================================
    # 输出面板
    # ============================================================
    def _build_output_panel(self):
        output_frame = tk.Frame(self.root, bg=self.bg_color)
        output_frame.pack(fill="both", expand=False, padx=10, pady=(0, 5))

        # 输出面板标题栏
        title_bar = tk.Frame(output_frame, bg=self.panel_color, height=36,
                             highlightthickness=1, highlightbackground=self.border_light)
        title_bar.pack(fill="x")
        title_bar.pack_propagate(False)

        tk.Label(title_bar, text="  📋 输出日志", bg=self.panel_color, fg=self.text_color,
                 font=("Microsoft YaHei", 10, "bold")).pack(side="left")

        # 状态标签
        self.output_status_var = tk.StringVar(value="● 就绪")
        tk.Label(title_bar, textvariable=self.output_status_var, bg=self.panel_color,
                 fg=self.success_color, font=("Microsoft YaHei", 9)).pack(side="right", padx=15)

        # 输出文本框
        output_inner = tk.Frame(output_frame, bg=self.panel_color,
                                highlightthickness=1, highlightbackground=self.border_light)
        output_inner.pack(fill="both", expand=True)

        self.output_text = scrolledtext.ScrolledText(
            output_inner, font=("Consolas", 10), bg="#0f172a", fg="#cbd5e1",
            insertbackground=self.accent_color, relief="flat", wrap="word",
            state="disabled", height=14, padx=10, pady=8,
            selectbackground="#1e40af", selectforeground="white",
            borderwidth=0, highlightthickness=0
        )
        self.output_text.pack(fill="both", expand=True, padx=0, pady=0)

        # 配置颜色标签（VSCode风格配色）
        self.output_text.tag_configure("info", foreground="#60a5fa")      # 蓝 - 信息
        self.output_text.tag_configure("warning", foreground="#fbbf24")   # 黄 - 警告
        self.output_text.tag_configure("error", foreground="#f87171")     # 红 - 错误
        self.output_text.tag_configure("success", foreground="#34d399")   # 绿 - 成功
        self.output_text.tag_configure("payload", foreground="#c084fc")   # 紫 - Payload
        self.output_text.tag_configure("data", foreground="#fb923c")      # 橙 - 数据
        self.output_text.tag_configure("highlight", background="#1e3a5f", foreground="white")

    # ============================================================
    # 状态栏
    # ============================================================
    def _build_statusbar(self):
        statusbar = tk.Frame(self.root, bg=self.panel_color, height=32,
                             highlightthickness=1, highlightbackground=self.border_light)
        statusbar.pack(fill="x", side="bottom")
        statusbar.pack_propagate(False)

        # 状态指示灯
        self.status_dot = tk.Label(statusbar, text="●", bg=self.panel_color,
                                   fg=self.success_color, font=("Arial", 10))
        self.status_dot.pack(side="left", padx=(12, 4), pady=6)

        self.status_var = tk.StringVar(value="就绪")
        tk.Label(statusbar, textvariable=self.status_var, bg=self.panel_color,
                 fg=self.text_secondary, font=("Microsoft YaHei", 9)).pack(side="left", padx=4)

        # 中间分隔
        tk.Label(statusbar, text="", bg=self.panel_color).pack(side="left", fill="x", expand=True)

    # ============================================================
    # 命令预览更新
    # ============================================================
    def _build_cmd_args(self):
        args = []

        # 目标
        url = self.target_url.get().strip()
        if url:
            args.append(f"-u \"{url}\"")

        # 请求方法
        method = self.request_method.get()
        if method != "GET":
            args.append(f"--method {method}")

        # POST数据
        post_data = self.post_data.get().strip()
        if post_data:
            args.append(f"--data \"{post_data}\"")

        # Cookie
        cookie = self.cookie.get().strip()
        if cookie:
            args.append(f"--cookie \"{cookie}\"")

        # 测试参数
        test_param = self.test_param.get().strip()
        if test_param:
            args.append(f"-p {test_param}")

        # DBMS
        dbms = self.dbms_type.get()
        if dbms != "自动识别":
            args.append(f"--dbms=\"{dbms}\"")

        # OS
        os_type = self.os_type.get()
        if os_type != "自动识别":
            args.append(f"--os={os_type}")

        # Level/Risk
        level = self.level_var.get()
        if level != 1:
            args.append(f"--level={level}")

        risk = self.risk_var.get()
        if risk != 1:
            args.append(f"--risk={risk}")

        # 注入技术
        techs = []
        if self.tech_be.get(): techs.append("B")
        if self.tech_e.get(): techs.append("E")
        if self.tech_u.get(): techs.append("U")
        if self.tech_s.get(): techs.append("S")
        if self.tech_t.get(): techs.append("T")
        if self.tech_q.get(): techs.append("Q")
        if len(techs) < 6:
            args.append(f"--technique={''.join(techs)}")

        # Tamper
        selected_tamper = [self.tamper_listbox.get(i) for i in self.tamper_listbox.curselection()]
        if selected_tamper:
            args.append(f"--tamper={','.join(selected_tamper)}")

        # 批处理
        if self.batch_mode.get():
            args.append("--batch")

        # 随机UA
        if self.random_agent.get():
            args.append("--random-agent")

        # 忽略重定向
        if self.ignore_redirects.get():
            args.append("--ignore-redirects")

        # 跳过WAF检测（移至高级选项区，避免重复）

        # 延迟
        delay = self.delay_var.get().strip()
        if delay and delay != "0":
            args.append(f"--delay={delay}")

        # 线程
        threads = self.threads.get().strip()
        if threads and threads != "1":
            args.append(f"--threads={threads}")

        # 超时
        timeout = self.timeout.get().strip()
        if timeout and timeout != "30":
            args.append(f"--timeout={timeout}")

        # 代理
        if self.use_proxy.get():
            proxy = self.proxy_addr.get().strip()
            if proxy:
                args.append(f"--proxy=\"{proxy}\"")

        # 忽略系统代理
        if self.ignore_proxy.get():
            args.append("--ignore-proxy")

        # Tor
        if self.tor_mode.get():
            args.append("--tor")

        # 强制SSL
        if self.force_ssl.get():
            args.append("--force-ssl")

        # 枚举选项
        if self.enum_banner.get():
            args.append("--banner")
        if self.enum_current_user.get():
            args.append("--current-user")
        if self.enum_current_db.get():
            args.append("--current-db")
        if self.enum_dbs.get():
            args.append("--dbs")
        if self.enum_tables.get():
            args.append("--tables")
        if self.enum_columns.get():
            args.append("--columns")
        if self.enum_dump.get():
            args.append("--dump")
        if self.enum_dump_all.get():
            args.append("--dump-all")
        if self.enum_passwords.get():
            args.append("--passwords")
        if self.enum_users.get():
            args.append("--users")
        if self.enum_privileges.get():
            args.append("--privileges")
        if self.enum_roles.get():
            args.append("--roles")

        # 指定枚举
        enum_db = self.enum_db.get().strip()
        if enum_db:
            args.append(f"-D \"{enum_db}\"")
        enum_table = self.enum_table.get().strip()
        if enum_table:
            args.append(f"-T \"{enum_table}\"")
        enum_column = self.enum_column.get().strip()
        if enum_column:
            args.append(f"-C \"{enum_column}\"")
        enum_where = self.enum_where.get().strip()
        if enum_where:
            args.append(f"--where=\"{enum_where}\"")

        # 文件操作
        if self.file_read.get() and self.file_read_path.get().strip():
            args.append(f"--file-read=\"{self.file_read_path.get().strip()}\"")
        if self.file_write.get() and self.file_write_src.get().strip() and self.file_write_dest.get().strip():
            args.append(f"--file-write=\"{self.file_write_src.get().strip()}\"")
            args.append(f"--file-dest=\"{self.file_write_dest.get().strip()}\"")

        # OS Shell（互斥：优先 --os-cmd，若同时勾选 --os-shell 则用 --os-shell）
        os_cmd = self.os_cmd.get().strip()
        if self.os_shell.get():
            args.append("--os-shell")
        elif os_cmd:
            args.append(f"--os-cmd=\"{os_cmd}\"")

        # 高级选项
        if self.forms.get():
            args.append("--forms")
        if self.crawl.get():
            depth = self.crawl_depth.get().strip() or "2"
            args.append(f"--crawl={depth}")
        if self.csrf.get():
            token_name = self.csrf_token_name.get().strip()
            if token_name:
                args.append(f"--csrf-token={token_name}")
            # 留空时不添加 --csrf-token，sqlmap 要求该参数必须带值
        if self.skip_heuristic.get():
            args.append("--skip-heuristics")
        if self.skip_waf.get():
            args.append("--skip-waf")
        if self.common_tables.get():
            args.append("--common-tables")
        if self.common_columns.get():
            args.append("--common-columns")
        if self.common_files.get():
            args.append("--common-files")
        if self.eta_show.get():
            args.append("--eta")
        if self.hex_convert.get():
            args.append("--hex")
        if self.optimize.get():
            args.append("-o")
        if self.no_cast.get():
            args.append("--no-cast")

        # 输出目录
        out_dir = self.output_dir.get().strip()
        if out_dir:
            args.append(f"--output-dir=\"{out_dir}\"")

        # 自定义Headers（合并为一个 --headers 参数，多行用 \n 分隔）
        headers = self.headers_text.get("1.0", "end").strip()
        if headers:
            header_lines = [l.strip() for l in headers.split("\n") if l.strip() and ":" in l]
            if header_lines:
                args.append(f'--headers="' + '\\n'.join(header_lines) + '"')

        # 自定义参数
        custom = self.custom_args.get().strip()
        if custom:
            args.append(custom)

        return args

    def _on_tamper_hover(self, event):
        """鼠标悬停tamper列表时显示浮动tooltip"""
        try:
            index = self.tamper_listbox.nearest(event.y)
            if index < 0 or index >= self.tamper_listbox.size():
                self._hide_tamper_tooltip()
                return

            # 检查鼠标是否真的在这一行上
            bbox = self.tamper_listbox.bbox(index)
            if not bbox or event.y < bbox[1] or event.y > bbox[1] + bbox[3]:
                self._hide_tamper_tooltip()
                return

            script = self.tamper_listbox.get(index)
            if script == self._tooltip_script and self._tooltip_win:
                return  # 同一个脚本，不重复创建

            desc = TAMPER_DESC.get(script, "暂无说明")
            self._show_tamper_tooltip(script, desc, event.x_root, event.y_root)
        except:
            pass

    def _show_tamper_tooltip(self, script, desc, x, y):
        """显示浮动tooltip窗口"""
        self._hide_tamper_tooltip()
        self._tooltip_script = script

        win = tk.Toplevel(self.root)
        win.wm_overrideredirect(True)  # 无边框
        win.wm_geometry(f"+{x + 15}+{y + 15}")
        win.attributes("-topmost", True)
        win.configure(bg=self.border_color)  # 边框色

        # 内容容器
        container = tk.Frame(win, bg="#1e293b", padx=12, pady=10)
        container.pack(padx=1, pady=1)

        # 脚本名称
        tk.Label(container, text=script, bg="#1e293b", fg="#3b82f6",
                 font=("Consolas", 10, "bold")).pack(anchor="w")

        # 分隔线
        tk.Frame(container, height=1, bg="#334155").pack(fill="x", pady=6)

        # 描述文字
        tk.Label(container, text=desc, bg="#1e293b", fg="#f1f5f9",
                 font=("Microsoft YaHei", 9), wraplength=280, justify="left"
                 ).pack(anchor="w")

        self._tooltip_win = win

    def _hide_tamper_tooltip(self, event=None):
        """隐藏浮动tooltip"""
        if self._tooltip_win:
            try:
                self._tooltip_win.destroy()
            except:
                pass
            self._tooltip_win = None
            self._tooltip_script = None

    def _update_cmd_preview(self):
        args = self._build_cmd_args()
        cmd = f"python sqlmap.py {' '.join(args)}" if args else "python sqlmap.py -u <target>"
        self.cmd_preview_var.set(cmd)

    # ============================================================
    # 开始/停止扫描
    # ============================================================
    def _start_scan(self):
        url = self.target_url.get().strip()
        if not url:
            messagebox.showwarning("提示", "请输入目标 URL")
            return

        # 验证文件写入参数
        if self.file_write.get():
            src = self.file_write_src.get().strip()
            dest = self.file_write_dest.get().strip()
            if not src:
                messagebox.showwarning("提示", "请选择本地源文件 (--file-write)")
                return
            if not os.path.exists(src):
                messagebox.showwarning("提示", f"源文件不存在：\n{src}")
                return
            if not dest:
                messagebox.showwarning("提示", "请填写目标路径 (--file-dest)")
                return

        # 构建命令参数
        cmd_args = self._build_run_args()

        # 找Python路径：优先使用配置的路径，否则回退到当前解释器
        python_path = getattr(self, "python_path", "")
        if not python_path or not os.path.exists(python_path):
            python_path = sys.executable

        full_cmd = [python_path, SQLMAP_PATH] + cmd_args

        # 在新控制台窗口中运行
        try:
            import subprocess

            # 生成启动脚本（纯ASCII，避免编码问题）
            bat_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "run_sqlmap.bat")
            bat_lines = []
            bat_lines.append("@echo off")
            bat_lines.append("chcp 65001 >nul")
            # title中的特殊字符需要转义
            safe_title = url[:50].replace("^", "^^").replace("&", "^&").replace("|", "^|").replace("<", "^<").replace(">", "^>")
            bat_lines.append(f"title sqlmap - {safe_title}")
            bat_lines.append(f"cd /d \"{os.path.dirname(os.path.abspath(__file__))}\"")
            bat_lines.append("echo.")
            bat_lines.append("echo [sqlmap GUI] Starting sqlmap...")
            bat_lines.append("echo.")

            # 构造命令行
            cmd_parts = []
            cmd_parts.append(f'"{python_path}"')
            cmd_parts.append(f'"{SQLMAP_PATH}"')
            for arg in cmd_args:
                # 包含特殊字符的用引号包起来
                if any(c in arg for c in ' &|^<>"%'):
                    # CMD 中双引号内：% 需转义为 %%，内部双引号用 ""
                    escaped = arg.replace('%', '%%').replace('"', '""')
                    cmd_parts.append(f'"{escaped}"')
                else:
                    cmd_parts.append(arg)
            cmd_line = ' '.join(cmd_parts)

            bat_lines.append(cmd_line)
            bat_lines.append("echo.")
            bat_lines.append("echo.")
            bat_lines.append("echo [sqlmap GUI] Scan finished.")
            bat_lines.append("pause")

            # 用gbk编码写入（CMD默认编码），纯ASCII内容不会有问题
            with open(bat_path, "w", encoding="gbk", errors="replace", newline="\r\n") as f:
                f.write("\n".join(bat_lines) + "\n")

            # 启动新窗口
            os.startfile(bat_path)

            self.status_var.set("已在终端中启动")
            self._append_output(f"[*] 已在新窗口中启动 sqlmap\n", "info")
            self._append_output(f"[*] 命令: {self.cmd_preview_var.get()}\n", "info")
        except Exception as e:
            messagebox.showerror("错误", f"启动失败: {e}")

    def _build_run_args(self):
        """构建运行时参数列表（list形式）"""
        args = []

        # 目标
        url = self.target_url.get().strip()
        if url:
            args.extend(["-u", url])

        # 请求方法
        method = self.request_method.get()
        if method != "GET":
            args.extend(["--method", method])

        # POST数据
        post_data = self.post_data.get().strip()
        if post_data:
            args.extend(["--data", post_data])

        # Cookie
        cookie = self.cookie.get().strip()
        if cookie:
            args.extend(["--cookie", cookie])

        # 测试参数
        test_param = self.test_param.get().strip()
        if test_param:
            args.extend(["-p", test_param])

        # DBMS
        dbms = self.dbms_type.get()
        if dbms != "自动识别":
            args.extend(["--dbms", dbms])

        # OS
        os_type = self.os_type.get()
        if os_type != "自动识别":
            args.extend(["--os", os_type])

        # Level/Risk
        level = self.level_var.get()
        if level != 1:
            args.extend(["--level", str(level)])
        risk = self.risk_var.get()
        if risk != 1:
            args.extend(["--risk", str(risk)])

        # 注入技术
        techs = []
        if self.tech_be.get(): techs.append("B")
        if self.tech_e.get(): techs.append("E")
        if self.tech_u.get(): techs.append("U")
        if self.tech_s.get(): techs.append("S")
        if self.tech_t.get(): techs.append("T")
        if self.tech_q.get(): techs.append("Q")
        if len(techs) < 6:
            args.extend(["--technique", "".join(techs)])

        # Tamper
        selected_tamper = [self.tamper_listbox.get(i) for i in self.tamper_listbox.curselection()]
        if selected_tamper:
            args.extend(["--tamper", ",".join(selected_tamper)])

        # 各种标志
        if self.batch_mode.get():
            args.append("--batch")
        if self.random_agent.get():
            args.append("--random-agent")
        if self.ignore_redirects.get():
            args.append("--ignore-redirects")
        if self.skip_waf.get():
            args.append("--skip-waf")
        if self.ignore_proxy.get():
            args.append("--ignore-proxy")
        if self.tor_mode.get():
            args.append("--tor")
        if self.force_ssl.get():
            args.append("--force-ssl")
        if self.optimize.get():
            args.append("-o")
        if self.hex_convert.get():
            args.append("--hex")
        if self.no_cast.get():
            args.append("--no-cast")
        if self.forms.get():
            args.append("--forms")
        if self.crawl.get():
            depth = self.crawl_depth.get().strip() or "2"
            args.extend(["--crawl", depth])
        if self.csrf.get():
            token_name = self.csrf_token_name.get().strip()
            if token_name:
                args.extend(["--csrf-token", token_name])
            # 留空时不添加 --csrf-token，sqlmap 要求该参数必须带值
        if self.skip_heuristic.get():
            args.append("--skip-heuristics")
        if self.common_tables.get():
            args.append("--common-tables")
        if self.common_columns.get():
            args.append("--common-columns")
        if self.common_files.get():
            args.append("--common-files")
        if self.eta_show.get():
            args.append("--eta")

        # 延迟/线程/超时
        delay = self.delay_var.get().strip()
        if delay and delay != "0":
            args.extend(["--delay", delay])
        threads = self.threads.get().strip()
        if threads and threads != "1":
            args.extend(["--threads", threads])
        timeout = self.timeout.get().strip()
        if timeout and timeout != "30":
            args.extend(["--timeout", timeout])

        # 代理
        if self.use_proxy.get():
            proxy = self.proxy_addr.get().strip()
            if proxy:
                args.extend(["--proxy", proxy])

        # 枚举选项
        if self.enum_banner.get():
            args.append("--banner")
        if self.enum_current_user.get():
            args.append("--current-user")
        if self.enum_current_db.get():
            args.append("--current-db")
        if self.enum_dbs.get():
            args.append("--dbs")
        if self.enum_tables.get():
            args.append("--tables")
        if self.enum_columns.get():
            args.append("--columns")
        if self.enum_dump.get():
            args.append("--dump")
        if self.enum_dump_all.get():
            args.append("--dump-all")
        if self.enum_passwords.get():
            args.append("--passwords")
        if self.enum_users.get():
            args.append("--users")
        if self.enum_privileges.get():
            args.append("--privileges")
        if self.enum_roles.get():
            args.append("--roles")

        # 指定枚举
        enum_db = self.enum_db.get().strip()
        if enum_db:
            args.extend(["-D", enum_db])
        enum_table = self.enum_table.get().strip()
        if enum_table:
            args.extend(["-T", enum_table])
        enum_column = self.enum_column.get().strip()
        if enum_column:
            args.extend(["-C", enum_column])
        enum_where = self.enum_where.get().strip()
        if enum_where:
            args.extend(["--where", enum_where])

        # 文件操作
        if self.file_read.get() and self.file_read_path.get().strip():
            args.extend(["--file-read", self.file_read_path.get().strip()])
        if self.file_write.get() and self.file_write_src.get().strip() and self.file_write_dest.get().strip():
            args.extend(["--file-write", self.file_write_src.get().strip()])
            args.extend(["--file-dest", self.file_write_dest.get().strip()])

        # OS命令（互斥：优先 --os-shell，若同时勾选则用 --os-shell）
        if self.os_shell.get():
            args.append("--os-shell")
        else:
            os_cmd = self.os_cmd.get().strip()
            if os_cmd:
                args.extend(["--os-cmd", os_cmd])

        # 输出目录
        out_dir = self.output_dir.get().strip()
        if out_dir:
            args.extend(["--output-dir", out_dir])

        # 自定义Headers（合并为一个 --headers 参数，多行用 \n 分隔）
        headers = self.headers_text.get("1.0", "end").strip()
        if headers:
            header_lines = [l.strip() for l in headers.split("\n") if l.strip() and ":" in l]
            if header_lines:
                args.extend(["--headers", "\n".join(header_lines)])

        # 自定义参数
        custom = self.custom_args.get().strip()
        if custom:
            import shlex
            try:
                # Windows 下用 posix=False 避免反斜杠路径被错误处理
                custom_parts = shlex.split(custom, posix=(os.name != 'nt'))
                args.extend(custom_parts)
            except:
                args.append(custom)

        return args

    def _stop_scan(self):
        self.status_var.set("终端模式下请在cmd窗口中按 Ctrl+C 停止")
        self._append_output("\n[!] 终端模式：请在cmd窗口中按 Ctrl+C 停止\n", "warning")

    # ============================================================
    # 工具方法
    # ============================================================
    def _append_output(self, text, tag=None):
        self.output_text.config(state="normal")
        if tag:
            self.output_text.insert("end", text, tag)
        else:
            self.output_text.insert("end", text)
        self.output_text.see("end")
        self.output_text.config(state="disabled")

    def _set_python_path(self):
        """设置 Python 解释器路径"""
        current = getattr(self, "python_path", "") or sys.executable
        path = filedialog.askopenfilename(
            title="选择 Python 解释器",
            initialdir=os.path.dirname(current) if os.path.exists(current) else "",
            filetypes=[("Python 解释器", "python.exe pythonw.exe"), ("可执行文件", "*.exe"), ("所有文件", "*.*")]
        )
        if path:
            self.python_path = path
            self._save_auto_config()
            messagebox.showinfo("成功", f"Python 路径已设置为：\n{path}")

    def _open_output_dir(self):
        out_dir = self.output_dir.get().strip() or DEFAULT_OUTPUT_DIR
        if out_dir:
            if not os.path.exists(out_dir):
                try:
                    os.makedirs(out_dir, exist_ok=True)
                except:
                    pass
            if os.path.exists(out_dir):
                os.startfile(out_dir)
            else:
                messagebox.showinfo("提示", "输出目录不存在")
        else:
            messagebox.showinfo("提示", "输出目录未设置")

    def _choose_output_dir(self):
        directory = filedialog.askdirectory(title="选择输出目录", initialdir=self.output_dir.get())
        if directory:
            self.output_dir.set(directory)
            self._update_cmd_preview()

    def _choose_local_file(self, var, title="选择文件"):
        """选择本地文件（用于 --file-write 的源文件）"""
        path = filedialog.askopenfilename(title=title)
        if path:
            var.set(path)
            self._update_cmd_preview()

    def _load_config(self):
        """启动时自动加载上次的配置"""
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    config = json.load(f)
                # 恢复窗口大小和位置
                if "geometry" in config and config["geometry"]:
                    self.root.geometry(config["geometry"])
                # 恢复 Python 路径
                if "python_path" in config:
                    self.python_path = config["python_path"]
                else:
                    self.python_path = ""
                if "target_url" in config:
                    self.target_url.set(config["target_url"])
                if "method" in config:
                    self.request_method.set(config["method"])
                if "post_data" in config:
                    self.post_data.set(config["post_data"])
                if "cookie" in config:
                    self.cookie.set(config["cookie"])
                if "level" in config:
                    self.level_var.set(config["level"])
                if "risk" in config:
                    self.risk_var.set(config["risk"])
                if "dbms" in config:
                    self.dbms_type.set(config["dbms"])
                self._update_cmd_preview()
        except:
            pass

    def _save_auto_config(self):
        """关闭时自动保存常用配置"""
        try:
            config = {
                "geometry": self.root.geometry(),
                "python_path": getattr(self, "python_path", ""),
                "target_url": self.target_url.get(),
                "method": self.request_method.get(),
                "post_data": self.post_data.get(),
                "cookie": self.cookie.get(),
                "level": self.level_var.get(),
                "risk": self.risk_var.get(),
                "dbms": self.dbms_type.get(),
            }
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
        except:
            pass

    def _save_config_dialog(self):
        path = filedialog.asksaveasfilename(
            title="保存配置", defaultextension=".json",
            filetypes=[("JSON配置文件", "*.json"), ("所有文件", "*.*")]
        )
        if path:
            config = {
                "target_url": self.target_url.get(),
                "method": self.request_method.get(),
                "post_data": self.post_data.get(),
                "cookie": self.cookie.get(),
                "level": self.level_var.get(),
                "risk": self.risk_var.get(),
                "dbms": self.dbms_type.get(),
            }
            try:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(config, f, ensure_ascii=False, indent=2)
                messagebox.showinfo("成功", "配置已保存")
            except Exception as e:
                messagebox.showerror("错误", f"保存失败: {e}")

    def _load_config_dialog(self):
        path = filedialog.askopenfilename(
            title="加载配置",
            filetypes=[("JSON配置文件", "*.json"), ("所有文件", "*.*")]
        )
        if path and os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                if "target_url" in config:
                    self.target_url.set(config["target_url"])
                if "method" in config:
                    self.request_method.set(config["method"])
                if "post_data" in config:
                    self.post_data.set(config["post_data"])
                if "cookie" in config:
                    self.cookie.set(config["cookie"])
                if "level" in config:
                    self.level_var.set(config["level"])
                if "risk" in config:
                    self.risk_var.set(config["risk"])
                if "dbms" in config:
                    self.dbms_type.set(config["dbms"])
                self._update_cmd_preview()
                messagebox.showinfo("成功", "配置已加载")
            except Exception as e:
                messagebox.showerror("错误", f"加载失败: {e}")

    def _show_about(self):
        messagebox.showinfo(
            "关于",
            "sqlmap GUI v0.1\n\n"
            "基于 sqlmap 的图形化渗透测试工具\n"
            "sqlmap 是一个开源的SQL注入自动化检测与利用工具\n\n"
            "本GUI仅供学习研究使用，请勿用于非法用途"
        )

    def _on_close(self):
        self._save_auto_config()
        # 终端模式下 sqlmap 在独立 cmd 窗口运行，关闭 GUI 不会终止扫描
        if messagebox.askokcancel("退出", "sqlmap 在独立终端中运行，关闭本窗口不会终止扫描。\n\n确定退出？"):
            self.root.destroy()
      

def main():
    # Windows 高 DPI 修复，解决界面模糊问题
    if sys.platform == "win32":
        try:
            # Windows 8.1+ 支持 Per-Monitor DPI
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            try:
                # Windows Vista/7 兼容方案
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass

    root = tk.Tk()
    app = SqlmapGUI(root)
    root.protocol("WM_DELETE_WINDOW", app._on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
